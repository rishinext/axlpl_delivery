#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=/Users/apple/fvm/versions/3.27.2"
export "FLUTTER_APPLICATION_PATH=/Users/apple/Desktop/flutter_project/axlpl_delivery"
export "COCOAPODS_PARALLEL_CODE_SIGN=true"
export "FLUTTER_TARGET=/Users/apple/Desktop/flutter_project/axlpl_delivery/lib/main.dart"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_BUILD_NAME=22.1.0"
export "FLUTTER_BUILD_NUMBER=26"
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=true"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=/Users/apple/Desktop/flutter_project/axlpl_delivery/.dart_tool/package_config.json"
